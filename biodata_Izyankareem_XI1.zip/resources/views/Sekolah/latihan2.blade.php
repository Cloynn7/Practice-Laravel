@extends('Sekolah.index')

@section('content')
<div>
    <h1>Tampilan view 2 menggunakan Laravel</h1>
    <h3>Berikut tampilan Route menggunakan file View Blade</h3>
</div>
@endsection