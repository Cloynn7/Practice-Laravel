@extends('errors::errorPage')

@section('title', __('Service Unavailable'))
@section('code', '503')
@section('errorMessage', __('Service Unavailable'))
