@extends('errors::errorPage')

@section('title', __('Not Found'))
@section('code', '404')
@section('errorMessage', __('Not Found'))