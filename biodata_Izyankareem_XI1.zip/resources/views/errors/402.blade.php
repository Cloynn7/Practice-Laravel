@extends('errors::errorPage')

@section('title', __('Payment Required'))
@section('code', '402')
@section('errorMessage', __('Payment Required'))
