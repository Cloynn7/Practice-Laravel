@extends('errors::errorPage')

@section('title', __('Page Expired'))
@section('code', '419')
@section('errorMessage', __('Page Expired'))
