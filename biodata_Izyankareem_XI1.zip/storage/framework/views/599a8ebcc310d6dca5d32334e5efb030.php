<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

<body>
    <div class="flex flex-col justify-center items-center h-screen text-center">
        <h1 class="mb-4 text-6xl font-semibold text-red-500"><?php echo $__env->yieldContent('code'); ?></h1>
        <p class="text-lg text-gray-600">Oops! It seems an error has occurred.</p>
        <p class="mt-1 text-gray-600">Let's take you <a href="/" class="text-blue-500">home</a>.</p>
    </div>
    </div>
</body>

</html>

<body>
<?php /**PATH C:\xampp\htdocs\Practice-Laravel\resources\views/errors/errorPage.blade.php ENDPATH**/ ?>