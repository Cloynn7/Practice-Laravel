<nav class="bg-slate-800 py-4 text-white flex justify-center">
    <div class="flex justify-between w-full md:w-5/6 mx-3 md:mx-0">
        <div class="flex items-center justify-center">
            <img src="<?php echo e(asset('images/logo-light.png')); ?>" alt="Logo" class="w-12 h-12 rounded-full">
            <h1 class="text-3xl ml-3 hidden md:block">Zynrr</h1>
        </div>
        <ul class="flex text-xl items-center">
            <li class="group mx-2 hover:scale-110 transition duration-200 ease-in-out relative">
                <a href="/" class="ease-in-out delay-110">
                    Home
                    <span
                        class="absolute w-full h-[3px] bg-gray-500 bottom-0 left-0 -mb-1 opacity-0 group-hover:opacity-100 transition duration-200 ease-in-out rounded-full"></span>
                </a>
            </li>
            <li class="group mx-2 hover:scale-110 transition duration-200 ease-in-out relative">
                <a href="/about" class="ease-in-out delay-110">
                    About
                    <span
                        class="absolute w-full h-[3px] bg-gray-500 bottom-0 left-0 -mb-1 opacity-0 group-hover:opacity-100 transition duration-200 ease-in-out rounded-full"></span>
                </a>
            </li>
            <li class="group mx-2 hover:scale-110 transition duration-200 ease-in-out relative">
                <a href="/contact" class="ease-in-out delay-110">
                    Contact
                    <span
                        class="absolute w-full h-[3px] bg-gray-500 bottom-0 left-0 -mb-1 opacity-0 group-hover:opacity-100 transition duration-200 ease-in-out rounded-full"></span>
                </a>
            </li>
        </ul>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\laravel-sch\resources\views/Layouts/navbar.blade.php ENDPATH**/ ?>