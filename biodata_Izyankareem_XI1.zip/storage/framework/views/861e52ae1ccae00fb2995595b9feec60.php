

<?php $__env->startSection('content'); ?>
ASU
<?php $__env->stopSection(); ?>
<?php echo $__env->make('defaultPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-sch\resources\views/Pages/register.blade.php ENDPATH**/ ?>