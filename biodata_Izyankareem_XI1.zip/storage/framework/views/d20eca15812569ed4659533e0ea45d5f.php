

<?php $__env->startSection('content'); ?>
    <div class="flex justify-around items-center h-screen bg-gray-700" id="content">
        <div>
            <div class="mb-10 text-white">
                <p class="text-4xl">Hello there,</p>
                <h1 class="text-8xl my-2">Im Izyankareem</h1>
                <h1 class="text-3xl">Im a
                    <span id="typed"></span>
                </h1>
            </div>
            <a class="bg-sky-700 text-white text-xl px-5 py-3 rounded-xl" href="/">Learn More</a>
            <a class="bg-sky-700 text-white text-xl px-5 py-3 rounded-xl" href="<?php echo e(url('others/CV.pdf')); ?>"
                download="Izyankareem CV">Download CV</a>
        </div>
        <img src="<?php echo e(asset('images/IMG_3144_cropped.png')); ?>" alt="Profile Picture" class="w-1/3 h-auto rounded-full"
            id="profile">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://unpkg.com/typed.js@2.0.16/dist/typed.umd.js"></script>
    <script>
        var typed = new Typed('#typed', {
            strings: ['Web Developer.', 'Student.'],
            typeSpeed: 70,
            backSpeed: 50,
            loop: true,
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('defaultPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-sch\resources\views/Pages/landing.blade.php ENDPATH**/ ?>