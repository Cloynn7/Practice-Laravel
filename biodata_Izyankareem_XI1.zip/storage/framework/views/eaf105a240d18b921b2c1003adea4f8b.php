<div>
    <h1>Tampilan view 2 menggunakan Laravel</h1>
    <p>Berikut tampilan Route menggunakan file View Blade</p>
</div><?php /**PATH C:\xampp\htdocs\laravel-sch\resources\views/sekolah/latihan2.blade.php ENDPATH**/ ?>