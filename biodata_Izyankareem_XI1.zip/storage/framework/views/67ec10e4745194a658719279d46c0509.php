<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->yieldContent('head'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?> 
    <?php echo $__env->yieldContent('css'); ?> 
    <title><?php echo $__env->yieldContent('title', 'Izyankareem'); ?></title>
</head>

<body>
    <?php echo $__env->make('Layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
</body>
<?php echo $__env->yieldContent('script'); ?>

</html>
<?php /**PATH C:\xampp\htdocs\laravel-sch\resources\views/defaultPage.blade.php ENDPATH**/ ?>