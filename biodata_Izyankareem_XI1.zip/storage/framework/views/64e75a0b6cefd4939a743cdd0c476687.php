

<?php $__env->startSection('content'); ?>
    <h1>Login</h1>

    <form method="POST" action="<?php echo e(route('')); ?>">
        <label for="username">Username</label>
        <input type="text" name="username" id="username">
        <label for="password">Password</label>
        <input type="password" name="password" id="password">
        <input type="submit" value="Login">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Sekolah.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-sch\resources\views/Sekolah/login.blade.php ENDPATH**/ ?>