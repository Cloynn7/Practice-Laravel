

<?php $__env->startSection('content'); ?>
<div>
    <h1>Tampilan view 2 menggunakan Laravel</h1>
    <h3>Berikut tampilan Route menggunakan file View Blade</h3>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Sekolah.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-sch\resources\views/Sekolah/latihan2.blade.php ENDPATH**/ ?>