<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <title>Document</title>
</head>

<body>
    <div class="flex flex-col justify-center items-center h-screen">
        <h1 class="block text-3xl">
            ❌ Oops! An error occurred.
        </h1>
        <p class="">Something went wrong</p>
    </div>
</body>

</html>

<body>
<?php /**PATH C:\xampp\htdocs\laravel-sch\resources\views/errorPage.blade.php ENDPATH**/ ?>