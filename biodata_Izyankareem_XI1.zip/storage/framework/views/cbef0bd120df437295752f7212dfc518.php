

<?php $__env->startSection('form'); ?>
    <form action="<?php echo e(route('hitung.luas')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
            <label for="jari_jari" class="col-sm-4 col-form-label">Jari jari</label>
            <div class="col-sm-8">
                <input type="text" name="jari_jari" class="form-control" id="jari_jari"">
            </div>
            <?php $__errorArgs = ['panjang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="row mb-3">
            <label for="inputPassword3" class="col-sm-4 col-form-label">Tinggi</label>
            <div class="col-sm-8">
                <input type="text" name="tinggi" class="form-control" id="tinggi">
            </div>
            <?php $__errorArgs = ['lebar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <?php if(@isset($luas)): ?>
            
        <div class="row mb-3">
            <label for="inputPassword3" class="col-sm-4 col-form-label">Area: </label>
            <div class="col-sm-8">
                <input type="text" name="luas" class="form-control" id="luas" value="<?php echo e($luas); ?>" readonly>
            </div>
        </div>
        <?php endif; ?>

        <button type="submit" class="btn btn-primary">Hitung Luas</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Sekolah.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-sch\resources\views/Sekolah/form.blade.php ENDPATH**/ ?>