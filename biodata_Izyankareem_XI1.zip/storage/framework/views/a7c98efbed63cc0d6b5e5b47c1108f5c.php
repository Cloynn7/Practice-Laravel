

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

<body>
    <div class="flex flex-col justify-center items-center h-screen">
        <h1 class="text-3xl font-bold">❌ Oops!</h1>
        <p class="my-5 text-xl">Sorry, an error has occured (<?php echo $__env->yieldContent('code'); ?>).</p>
        <p><?php echo $__env->yieldContent('message'); ?></p>
    </div>
</body>

</html>

<body>
<?php /**PATH C:\xampp\htdocs\laravel-sch\resources\views/errors/minimal.blade.php ENDPATH**/ ?>